To run the prediction_1.py file use

# The best model for part 1 is ResNet34 Adam E4

python .\prediction_1.py model_name model_path test_image_folder_path

# The model for part 2 is Custom CLR E5 SGD

To run the prediction_2.py file use

python .\prediction_2.py test_images_folder_path model_path